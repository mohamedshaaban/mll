function copyURI(evt) {
    evt.preventDefault();
    navigator.clipboard.writeText(evt.target.getAttribute('href')).then(() => {
        /* clipboard successfully set */
    }, () => {
        /* clipboard write failed */
    });
}
$('.modeltext-class').parent().fadeOut();

$('.not_exits_make-class').change(function() {
    if(this.checked) {
         $('.modeltext-class').parent().fadeIn();
        $('.modelselect-class').parent().fadeOut();
    }
    else
    {
         $('.modeltext-class').parent().fadeOut();
        $('.modelselect-class').parent().fadeIn();
    }
});

$( ".paymenttype-class" ).change(function() {
     if ($(this).val() == '2') {
          $('.paidpayment-class').parent().fadeOut();
    }
    else
    {

        $('.paidpayment-class').parent().fadeIn();
    }
});
