﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","zh-cn",{title:"用户界面颜色选择器",options:"颜色选项",highlight:"高亮",selected:"已选颜色",predefined:"预定义颜色集",config:"粘贴此字符串到您的 config.js 文件"});