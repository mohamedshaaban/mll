# YUMMY License

**YoU make Money, I make MoneY.** The license holder is allowed to use the software for free, as long as he doesn't make money by using it.

Copyright (c) 2015-2017 Cristian Tabacitu <hello@tabacitu.ro>

## FREE for non-commercial use, PAID for commercial use

> Permission is hereby granted to any person obtaining a copy of this software 
> and associated documentation files (the "Software"), to use the Software. 
> This includes the rights to use, copy, modify and/or merge the Sofware 
> or copies of the Software, and to permit persons to whom the Software is 
> furnished to do so, subject to the following conditions:
>
> **1. Should the Sofware be used for non-commercial purposes (personal use, not-profits,
> testing, education), no financial reward is expected and the above rights are given FREE OF CHARGE.**
>
> **2. Should the Software be used for commercial purposes (the user of this Sofware, 
> its employer, employees or clients make money by using this Software), the user is 
> required to purchase a "Single Domain License" on [backpackforlaravel.com](https://backpackforlaravel.com), for each
> domain name this sofware will be used on, before its usage in production.
> Failure to do so will constitute as illegal commercial use.**
> 
> **3. This license does not include the rights to publish or sublicense
> this Sofware, its copies or any derivations, with or without the purpose of commercial profit. 
> For inclusion in commercial packages or SaaS products, an "Unlimited License" is required, which can be purchased on [backpackforlaravel.com](https://backpackforlaravel.com). For inclusion in free open-source packages, express permission is needed from <hello@tabacitu.ro>.**
>
> **4. The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.**
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
> THE SOFTWARE.
